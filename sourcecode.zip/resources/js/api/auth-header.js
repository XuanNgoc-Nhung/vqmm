export function authHeader() {
    let data = {
        'Content-Type':"application/json; charset=utf-8",
    }
    return  data
}
