window.Vue = require('vue');
Vue.component('quan-ly-phan-thuong', require('./components/pages/quanLyPhanThuong').default);
new Vue({
    el: '#app'
});

