window.Vue = require('vue');
Vue.component('trang-chu', require('./components/pages/trangChu').default);
new Vue({
    el: '#app'
});

