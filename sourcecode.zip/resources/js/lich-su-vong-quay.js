window.Vue = require('vue');
Vue.component('lich-su-vong-quay', require('./components/pages/lishSuVongQuay').default);
new Vue({
    el: '#app'
});

