
<!-- jQuery -->
<script src="cdn/assets/js/jquery-3.6.0.min.js"></script>

<!-- Bootstrap Core JS -->
<script src="cdn/assets/js/bootstrap.bundle.min.js"></script>

<!-- Feather Icon JS -->
<script src="cdn/assets/js/feather.min.js"></script>

<!-- Select2 JS -->
<script src="cdn/assets/plugins/select2/js/select2.min.js"></script>

<!-- Slimscroll JS -->
<script src="cdn/assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Owl Carousel JS -->
<script src="cdn/assets/plugins/owl-carousel/owl.carousel.min.js"></script>

<!-- Chart JS -->
<script src="cdn/assets/plugins/apexchart/apexcharts.min.js"></script>
<script src="cdn/assets/plugins/apexchart/chart-data.js"></script>

<!-- Daterangepicker JS -->
<script src="cdn/assets/js/moment.min.js"></script>
<script src="cdn/assets/plugins/daterangepicker/daterangepicker.js"></script>

<!-- Custom JS -->
<script src="cdn/assets/js/script.js"></script>
