@extends('admin.layouts.app')
@section('title')
    <title>Trang chủ admin</title>
@endsection
@section('content')
    <div>
        Nội dung trang tổng quan
    </div>
@endsection
@section("js_location")
@endsection
