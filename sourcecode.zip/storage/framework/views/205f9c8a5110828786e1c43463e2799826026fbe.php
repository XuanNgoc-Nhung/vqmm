<?php $__env->startSection('title'); ?>
    <title>Lịch sử vòng quay</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="app">
        <lich-su-vong-quay/>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js_location"); ?>
    <script src="<?php echo e(asset('js/lich-su-vong-quay.js?t='.Carbon\Carbon::now()->timestamp)); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vong-quay-may-man\resources\views/admin/lich-su-quay.blade.php ENDPATH**/ ?>