<ul>
    <li class="menu-title"><span>Main</span></li>

    <li class="<?php echo e(Request::routeIs('admin.getHome') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.getHome')); ?>"><i class="feather-grid"></i> <span>Tổng quan</span></a>
    </li>
    <li class="<?php echo e(Request::routeIs('admin.quanLyPhanThuong') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.quanLyPhanThuong')); ?>"><i class="feather-calendar"></i> <span>Quản lý phần thưởng</span></a>
    </li>
    <li class="<?php echo e(Request::routeIs('admin.lichSu') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.lichSu')); ?>"><i class="feather-calendar"></i> <span>Lịch sử</span></a>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\vong-quay-may-man\resources\views/admin/layouts/menu.blade.php ENDPATH**/ ?>