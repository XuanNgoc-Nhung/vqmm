
<base href="<?php echo e(asset('')); ?>">
<link rel="shortcut icon" href="cdn/assets/img/favicon.png">
<link rel="stylesheet" href="cdn/assets/css/bootstrap.min.css">
<!-- Fontawesome CSS -->
<link rel="stylesheet" href="cdn/assets/plugins/fontawesome/css/fontawesome.min.css">
<link rel="stylesheet" href="cdn/assets/plugins/fontawesome/css/all.min.css">

<!-- Feathericon CSS -->
<link rel="stylesheet" href="cdn/assets/css/feather.css">

<!-- Select2 CSS-->
<link rel="stylesheet" href="cdn/assets/plugins/select2/css/select2.min.css">

<!-- Owl carousel CSS -->
<link rel="stylesheet" href="cdn/assets/plugins/owl-carousel/owl.carousel.min.css">

<!-- Daterangepicker CSS -->
<link rel="stylesheet" href="cdn/assets/plugins/daterangepicker/daterangepicker.css">

<!-- Main CSS -->
<link rel="stylesheet" href="cdn/assets/css/style.css">
<link rel="stylesheet" href="css/styleCustom.css">
<?php /**PATH C:\xampp\htdocs\vong-quay-may-man\resources\views/admin/layouts/link_css.blade.php ENDPATH**/ ?>