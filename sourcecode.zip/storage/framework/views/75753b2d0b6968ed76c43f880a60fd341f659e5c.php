<?php $__env->startSection('title'); ?>
    <title>Trang chủ admin</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        Nội dung trang tổng quan
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js_location"); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vong-quay-may-man\resources\views/admin/home.blade.php ENDPATH**/ ?>