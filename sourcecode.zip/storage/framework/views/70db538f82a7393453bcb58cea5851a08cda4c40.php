<?php $__env->startSection('title'); ?>
    <title>Quản lý phần thưởng</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="app">
        <quan-ly-phan-thuong/>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js_location"); ?>
    <script src="<?php echo e(asset('js/quan-ly-phan-thuong.js?t='.Carbon\Carbon::now()->timestamp)); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vong-quay-may-man\resources\views/admin/quan-ly-phan-thuong.blade.php ENDPATH**/ ?>